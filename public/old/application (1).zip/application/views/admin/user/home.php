<?php
	include"./fsy/url_induk.php";
?>
<!--Content-->
<div id="content">
<ul class="breadcrumb">
        <li><a href="#" class="glyphicons home">Home</a></li>
</ul>
<div class="innerLR">
        <!-- Widget -->
        <div class="widget widget-gray widget-body-gray">
                <div class="widget-body">
                        <!-- Row -->
                        <div class="row">
							<div class="col-md-12">
								<h4 class="panel-title"><b>Selamat Datang Administrator</b></h4><br>
								<img style="margin:auto;" src="<?=$assets?>images/shoplution-logo.png" class="img-responsive"/><br><br>
								<p><b>Terimakasih telah memilih Shoplution sebagai media berjualan online. Berbagai fitur yang terdapat di dalam website khusus kami kembangkan untuk menunjang keperluan Anda dalam berbisnis toko online. Untuk mengetahui tata cara pengelolaan website toko online dapat Anda baca di Buku Panduan yang telah kami sediakan.<br>
								Untuk mengunduh buku panduan silahkan <a href="<?=$MAIN_URL?>/Panduan Pengelolaan Toko Online.pdf" target="_blank">klik disini</a></b></p>
								<br>
								</br>
								</br>
								</br>
								<b>
								<p>Jika ada pertanyaan,silahkan hubungi kontak kami</p> 
								<p>Website: www.shoplution.co.id</p> 
								<p>Email: customer@shoplution.co.id/shoplution@gmail.com</p> 	
								<p>Telp: 022-61551322</p> 	
								<p>Jam Kerja: Senin-Jumat 09.00-18.00 (kecuali hari libur nasional)</p> 
								<p>Alamat: CV. Panca Putra Bangsa Media <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jln. Hijau Daun I No.03 Block C12 Komplek BIR Kota Bandung</p> 
								</b>
							</div>
                        </div> 
						<!-- // Row END -->
                </div>
        

</div>
</div>
                
                                <!-- End Wrapper -->
                </div>  




