<!-- Meta -->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	
	<!-- Bootstrap -->
	<link href="<?=$assets?>css/admin/bootstrap.css" rel="stylesheet">
	
	<!-- Bootstrap Extended -->
	<link href="<?=$assets?>css/admin/jasny-bootstrap.css" rel="stylesheet">
	<link href="<?=$assets?>css/admin/jasny-bootstrap-responsive.css" rel="stylesheet">
	<link href="<?=$assets?>css/admin/bootstrap-wysihtml5-0.0.2.css" rel="stylesheet">
	
	<!-- Select2 -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/select2.css">
	
	<!-- Notyfy -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/jquery.css">
	<link rel="stylesheet" href="<?=$assets?>css/admin/default.css">
	
	<!-- Gritter Notifications Plugin -->
	<link href="<?=$assets?>css/admin/jquery_003.css" rel="stylesheet">
	
	<!-- JQueryUI v1.9.2 -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/jquery-ui-1.css">
	
		
	<!-- glyphicons -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/glyphicons.css">
	
	
	<!-- font awesome -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/font-awesome.css">
	
	
	<!-- Bootstrap Extended -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/bootstrap-select.css">
	<!-- <link rel="stylesheet" href="../common/bootstrap/extend/bootstrap-toggle-buttons/static/stylesheets/bootstrap-toggle-buttons.css" /> -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/bootstrap-switch.css">
	
	<!-- Uniform -->
	<link rel="stylesheet" media="screen" href="<?=$assets?>css/admin/uniform.css">
	
	<!-- google-code-prettify -->
	<link href="<?=$assets?>css/admin/prettify.css" type="text/css" rel="stylesheet">
	

	
	<!-- JQuery v1.8.2 -->
	<!--<script src="<?=$assets?>js/admin/ga.js" async="" type="text/javascript"></script>-->
	<script src="<?=$assets?>js/admin/jquery-1.js"></script>
	
	<!-- Modernizr -->
	<script src="<?=$assets?>js/admin/modernizr.js"></script>
	
	<!-- MiniColors -->
	<link rel="stylesheet" media="screen" href="<?=$assets?>css/admin/jquery_002.css">
	
	<!-- Theme -->
	<link rel="stylesheet" href="<?=$assets?>css/admin/style.css">
	
	<!-- LESS 2 CSS -->
<script src="<?=$assets?>js/admin/less-1.js"></script>
<style type="text/css" id="holderjs-style">.holderjs-fluid {font-size:16px;font-weight:bold;text-align:center;font-family:sans-serif;margin:0}</style></head>
