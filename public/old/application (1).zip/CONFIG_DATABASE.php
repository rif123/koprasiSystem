<?php
/*----------------------Masukan host ,username, password dan nama  database yg bisa dilihat di Cpanel hosting--------------------*/
	$HOST			="localhost";
	$USERNAME		="u1901734_shop";
	$PASSWORD		="admin123";
	$DATABASE_NAME	="u1901734_shop";
	
?>