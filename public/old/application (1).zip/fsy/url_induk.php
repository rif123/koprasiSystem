<?php
	$MAIN_URL="http://shoplution.co.id";
?>