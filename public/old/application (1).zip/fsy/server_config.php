<?php
$HOST		="192.168.23.10:3306";
$USER		="admin";
$PASSWORD	="admin";
$DBNAME		="firecode_shop";
?>